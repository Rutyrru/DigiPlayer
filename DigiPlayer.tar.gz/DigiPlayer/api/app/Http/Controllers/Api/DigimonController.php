<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Digimon;

class DigimonController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $digimons = Digimon::all();
        return $digimons;
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request){
    
        $digimon = new Digimon();
        $digimon->name = $request->name;
        $digimon->last_name = $request->last_name;
        $digimon->job = $request->job;
        $digimon->phone = $request->phone;
        $digimon->address = $request->address;
        $digimon->age = $request->age;
        $digimon->save();
    }

    /**
     * Display the specified resource.
    */
    public function show(string $id)
    {
        $digimon = Digimon::find($id);
        return $digimon;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $digimon = Digimon::findOrFail($request->id);
        $digimon->name = $request->name;
        $digimon->last_name = $request->last_name;
        $digimon->job = $request->job;
        $digimon->phone = $request->phone;
        $digimon->address = $request->address;
        $digimon->age = $request->age;
        $digimon->save();
        return $digimon;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $digimon = Digimon::destroy($id);
        return $digimon;
    }
}
